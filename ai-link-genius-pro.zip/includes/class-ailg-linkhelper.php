<?php
/**
 * Link Helper Class
 */

defined( 'ABSPATH' ) || exit;

class AILG_LinkHelper {
    /**
     * Insert a link into content at the first occurrence of anchor text,
     * skipping any occurrence already inside an <a> tag.
     */
    public static function insert( string $content, string $anchor, string $link ): string {
        $done    = false;
        // Optimization: Use a more robust regex or DOMDocument if possible,
        // but keeping regex for performance on large content for now.
        $pattern = '/(?<!["\'>])(' . preg_quote( $anchor, '/' ) . ')(?![^<]*<\/a>)/u';
        $result  = preg_replace_callback(
            $pattern,
            function ( $m ) use ( $link, &$done ) {
                if ( $done ) return $m[0];
                $done = true;
                return $link;
            },
            $content
        );
        return $result ?? $content;
    }

    /**
     * Wrap an image with a specific alt text in a link.
     */
    public static function wrap_image( string $content, string $alt, string $link_url ): string {
        $pattern = '/(<img[^>]+alt=["\']' . preg_quote( $alt, '/' ) . '["\'][^>]*>)/i';
        // Ensure image isn't already linked
        $result = preg_replace_callback($pattern, function($m) use ($link_url) {
            return '<a href="' . esc_url($link_url) . '">' . $m[1] . '</a>';
        }, $content);

        return $result ?? $content;
    }
}