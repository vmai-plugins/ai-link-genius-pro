<?php
/**
 * Reports Class
 */

defined( 'ABSPATH' ) || exit;

class AILG_Reports {

    public static function ajax_dashboard_stats(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;

        $total_links         = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_links" );
        $pending_suggestions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_suggestions WHERE status='pending'" );
        $broken              = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_broken_links WHERE status='broken'" );

        // Orphaned: published posts with no inbound links (Optimized)
        $post_types   = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

        $orphaned = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(p.ID) FROM {$wpdb->posts} p
             WHERE p.post_status='publish' AND p.post_type IN ({$placeholders})
             AND p.ID NOT IN (SELECT DISTINCT target_id FROM {$wpdb->prefix}ailg_links)",
            ...$post_types
        ) );

        // Weekly chart (Optimized one-query fetch)
        $chart_data = [];
        $weekly_stats = $wpdb->get_results(
            "SELECT DATE(created_at) as date, COUNT(*) as count
             FROM {$wpdb->prefix}ailg_links
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(created_at)",
            OBJECT_K
        );

        for ( $i = 6; $i >= 0; $i-- ) {
            $date  = gmdate( 'Y-m-d', strtotime( "-{$i} days" ) );
            $label = gmdate( 'D', strtotime( "-{$i} days" ) );
            $count = isset( $weekly_stats[ $date ] ) ? (int) $weekly_stats[ $date ]->count : 0;
            $chart_data[] = [ 'l' => $label, 'v' => $count ];
        }

        wp_send_json_success( compact( 'total_links', 'pending_suggestions', 'orphaned', 'broken', 'chart_data' ) );
    }

    public static function ajax_report_data(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $post_types   = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}ailg_links WHERE target_id = p.ID) AS inbound,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}ailg_links WHERE post_id   = p.ID) AS outbound,
                    (SELECT SUM(clicks) FROM {$wpdb->prefix}ailg_link_analytics WHERE post_id = p.ID) AS clicks
             FROM {$wpdb->posts} p
             WHERE p.post_status = 'publish' AND p.post_type IN ({$placeholders})
             ORDER BY inbound DESC, outbound DESC
             LIMIT 100",
            ...$post_types
        ), ARRAY_A );

        foreach ( $posts as &$p ) {
            $p['edit_url'] = get_edit_post_link( (int) $p['ID'], 'raw' );
            $p['clicks']   = (int) ( $p['clicks'] ?? 0 );
            $inbound       = (int) $p['inbound'];
            $outbound      = (int) $p['outbound'];
            $p['link_score'] = min( 100, (int) round( ( $inbound * 60 + $outbound * 40 ) / max( 1, $inbound + $outbound ) ) );
        }
        unset( $p );

        wp_send_json_success( [ 'posts' => $posts ] );
    }

    public static function ajax_orphaned(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $post_types   = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_type, post_date FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ({$placeholders})
               AND ID NOT IN (SELECT DISTINCT target_id FROM {$wpdb->prefix}ailg_links)
             ORDER BY post_date DESC
             LIMIT 200",
            ...$post_types
        ), ARRAY_A );

        foreach ( $posts as &$p ) {
            $p['edit_url'] = get_edit_post_link( (int) $p['ID'], 'raw' );
        }
        unset( $p );

        wp_send_json_success( [ 'posts' => $posts ] );
    }

    public static function ajax_fix_orphaned(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );
        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'Invalid ID' );

        $ids = AILG_Scanner::get_orphan_fix_candidates( $post_id );

        wp_send_json_success( [ 'ids' => $ids ] );
    }

    public static function ajax_broken_links(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $post_types   = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_title, post_content FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ({$placeholders})
             LIMIT 10", // Legacy fallback
            ...$post_types
        ) );

        $broken = [];
        foreach ( $posts as $post ) {
            $post_broken = self::scan_broken_in_post( $post );
            $broken = array_merge( $broken, $post_broken );
        }

        wp_send_json_success( [ 'links' => $broken, 'checked' => count( $posts ) ] );
    }

    /**
     * Helper to scan a single post object for broken links, including deep scan of metadata.
     */
    private static function scan_broken_in_post( $post ): array {
        global $wpdb;
        $broken = [];

        // 1. Scan Main Content
        $content = $post->post_content;

        // 2. Deep Scan: Scan all Custom Fields (ACF, etc)
        $meta = get_post_meta( $post->ID );
        foreach ( $meta as $key => $values ) {
            foreach ( $values as $value ) {
                if ( is_string( $value ) && ( str_contains( $value, 'http' ) || str_contains( $value, '<a' ) ) ) {
                    $content .= ' ' . $value;
                }
            }
        }

        preg_match_all( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/i', $content, $matches );

        // Also find bare URLs in text that might be broken
        preg_match_all( '/https?:\/\/[^\s<"\']+/i', $content, $url_matches );
        $urls = array_unique( array_merge( $matches[1], $url_matches[0] ) );

        foreach ( $urls as $url ) {
            if ( empty( $url ) || str_starts_with( $url, '#' ) || str_starts_with( $url, 'mailto:' ) || str_starts_with( $url, 'tel:' ) ) continue;

            // Resolve relative URLs
            $full_url = $url;
            if ( str_starts_with( $url, '/' ) ) {
                $full_url = home_url( $url );
            } elseif ( ! str_starts_with( $url, 'http' ) ) {
                // Handle cases like "contact" (if it's a relative path from current page)
                // For simplicity in a global scan, we'll assume relative to root if it starts with a char
                $full_url = home_url( '/' . $url );
            }

            // Clean URL from trailing punctuation
            $full_url = rtrim( $full_url, '.,;)' );

            $resp = wp_remote_head( $full_url, [ 'timeout' => 8, 'redirection' => 5 ] );
            $code = is_wp_error( $resp ) ? 0 : (int) wp_remote_retrieve_response_code( $resp );

            // Identify Broken or Redirect chains
            if ( $code === 0 || $code >= 400 || ( $code >= 300 && $code < 400 ) ) {
                $item = [
                    'post_id'    => $post->ID,
                    'post_title' => $post->post_title,
                    'edit_url'   => get_edit_post_link( $post->ID, 'raw' ),
                    'url'        => $url,
                    'http_code'  => $code,
                ];
                $broken[] = $item;
                $wpdb->replace( "{$wpdb->prefix}ailg_broken_links", [
                    'post_id'  => $post->ID,
                    'url'      => $url,
                    'http_code'=> $code,
                    'status'   => $code >= 400 ? 'broken' : ( $code >= 300 ? 'redirect' : 'pending' ),
                ] );
            }
        }
        return $broken;
    }

    public static function ajax_get_broken_queue(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        $post_types = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $ids = get_posts( [
            'post_type'      => $post_types,
            'posts_per_page' => -1, // Fetch ALL for enterprise
            'post_status'    => 'publish',
            'fields'         => 'ids',
        ] );

        wp_send_json_success( [ 'ids' => $ids ] );
    }

    public static function ajax_scan_broken_single(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        if ( ! $post_id ) wp_send_json_error( 'Invalid post ID' );

        $post = get_post( $post_id );
        if ( ! $post ) wp_send_json_error( 'Post not found' );

        $broken = self::scan_broken_in_post( $post );

        wp_send_json_success( [ 'links' => $broken ] );
    }

    /**
     * Remove a specific link from a post's content while keeping the anchor text.
     */
    public static function ajax_unlink_broken(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) wp_die( -1 );

        $post_id = (int) ( $_POST['post_id'] ?? 0 );
        $url     = esc_url_raw( (string) ( $_POST['url'] ?? '' ) );

        if ( ! $post_id || empty( $url ) ) wp_send_json_error( 'Invalid request' );

        $post = get_post( $post_id );
        if ( ! $post ) wp_send_json_error( 'Post not found' );

        // Regex to find the <a> tag with this href and strip it
        $pattern = '/<a[^>]+href=["\']' . preg_quote( $url, '/' ) . '["\'][^>]*>(.*?)<\/a>/i';
        $new_content = preg_replace( $pattern, '$1', $post->post_content );

        if ( $new_content !== $post->post_content ) {
            wp_update_post( [ 'ID' => $post_id, 'post_content' => $new_content ] );

            global $wpdb;
            $wpdb->delete( "{$wpdb->prefix}ailg_broken_links", [ 'post_id' => $post_id, 'url' => $url ] );

            wp_send_json_success( [ 'message' => 'Link removed successfully.' ] );
        }

        wp_send_json_error( 'Link not found in content.' );
    }

    /**
     * Audit semantic coverage and topical connectivity gaps.
     */
    public static function ajax_semantic_audit(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $post_types = (array) get_option( 'ailg_auto_link_post_types', [ 'post', 'page' ] );
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

        // 1. Identify Pillars (using RM or by inbound link count > 5)
        $pillars = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title FROM {$wpdb->posts} p
             WHERE p.post_status = 'publish' AND p.post_type IN ({$placeholders})
             AND (
                EXISTS (SELECT 1 FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = 'rank_math_pillar_content' AND meta_value = 'on')
                OR (SELECT COUNT(*) FROM {$wpdb->prefix}ailg_links WHERE target_id = p.ID) > 5
             ) LIMIT 10",
            ...$post_types
        ) );

        $gaps = [];
        foreach ( $pillars as $pillar ) {
            $cat_ids = wp_get_post_categories( $pillar->ID );
            if ( empty( $cat_ids ) ) continue;

            $cat_ids_str = implode( ',', array_map( 'intval', $cat_ids ) );

            // Posts in same categories
            $total_related = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
                 WHERE tr.term_taxonomy_id IN (SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id IN ($cat_ids_str))
                   AND p.post_status = 'publish' AND p.post_type IN ({$placeholders}) AND p.ID != %d",
                ...array_merge( $post_types, [ $pillar->ID ] )
            ) );

            if ( $total_related === 0 ) continue;

            // Related posts that DO link to this pillar
            $linked = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->prefix}ailg_links
                 WHERE target_id = %d AND post_id IN (
                    SELECT p.ID FROM {$wpdb->posts} p
                    INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
                    WHERE tr.term_taxonomy_id IN (SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id IN ($cat_ids_str))
                 )",
                $pillar->ID
            ) );

            $coverage = round( ( $linked / $total_related ) * 100 );

            if ( $coverage < 60 ) {
                $gaps[] = [
                    'pillar_id'    => $pillar->ID,
                    'pillar_title' => $pillar->post_title,
                    'coverage'     => $coverage,
                    'missing'      => $total_related - $linked,
                    'total'        => $total_related
                ];
            }
        }

        wp_send_json_success( [ 'gaps' => $gaps ] );
    }

    /**
     * Get internal links with low/zero clicks.
     */
    public static function ajax_get_link_decay(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $decayed = $wpdb->get_results(
            "SELECT l.*, a.clicks, a.last_update, p.post_title as source_title
             FROM {$wpdb->prefix}ailg_links l
             LEFT JOIN {$wpdb->prefix}ailg_link_analytics a ON l.post_id = a.post_id AND l.target_id = a.target_id
             LEFT JOIN {$wpdb->posts} p ON l.post_id = p.ID
             WHERE l.link_type = 'internal'
               AND (a.clicks < 2 OR a.clicks IS NULL)
               AND l.created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
             ORDER BY l.created_at ASC
             LIMIT 50",
            ARRAY_A
        );

        wp_send_json_success( [ 'decayed' => $decayed ] );
    }

    /**
     * Export all internal links as a Graph (Nodes & Edges).
     */
    public static function ajax_get_link_graph(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        $links = $wpdb->get_results( "SELECT post_id, target_id FROM {$wpdb->prefix}ailg_links WHERE link_type = 'internal'" );

        $nodes = [];
        $edges = [];

        // Track unique post IDs
        $post_ids = [];
        foreach ( $links as $l ) {
            $post_ids[] = (int) $l->post_id;
            $post_ids[] = (int) $l->target_id;
            $edges[] = [ 'source' => (int) $l->post_id, 'target' => (int) $l->target_id ];
        }
        $post_ids = array_unique( $post_ids );

        foreach ( $post_ids as $id ) {
            $nodes[] = [
                'id'    => $id,
                'label' => get_the_title( $id ),
                'url'   => get_edit_post_link( $id, 'raw' )
            ];
        }

        wp_send_json_success( [ 'nodes' => $nodes, 'edges' => $edges ] );
    }

    /**
     * Automatically update all internal links that point to a redirect URL.
     */
    public static function ajax_groom_redirects(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        global $wpdb;
        // Find all internal redirects we've logged
        $redirects = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}ailg_broken_links WHERE status = 'redirect'" );

        $groomed_count = 0;
        foreach ( $redirects as $r ) {
            // Get the final destination URL
            $resp = wp_remote_head( $r->url, [ 'timeout' => 5, 'redirection' => 5 ] );
            if ( is_wp_error( $resp ) ) continue;

            $final_url = wp_remote_retrieve_header( $resp, 'location' );
            if ( empty( $final_url ) ) {
                // If header is empty, the current response might be the 200 OK after redirection
                $code = (int) wp_remote_retrieve_response_code( $resp );
                if ( $code === 200 ) {
                     // We need to find where it went. Head doesn't always show the full trail.
                     // For internal grooming, we'll assume the URL we have is the redirected one.
                     continue;
                }
            }

            // Update post content: swap $r->url for $final_url
            $posts_to_update = $wpdb->get_results( $wpdb->prepare(
                "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_content LIKE %s",
                '%' . $wpdb->esc_like( $r->url ) . '%'
            ) );

            foreach ( $posts_to_update as $p ) {
                $new_content = str_replace( $r->url, $final_url, $p->post_content );
                if ( $new_content !== $p->post_content ) {
                    wp_update_post( [ 'ID' => $p->ID, 'post_content' => $new_content ] );
                    $groomed_count++;
                }
            }

            // Mark as fixed in our log
            $wpdb->update( "{$wpdb->prefix}ailg_broken_links", [ 'status' => 'ok' ], [ 'id' => $r->id ] );
        }

        wp_send_json_success( [ 'message' => "Successfully groomed $groomed_count links." ] );
    }

    /**
     * Global internal link URL swapper.
     */
    public static function ajax_global_swap(): void {
        check_ajax_referer( 'ailg_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

        $old_url = esc_url_raw( (string) ( $_POST['old_url'] ?? '' ) );
        $new_url = esc_url_raw( (string) ( $_POST['new_url'] ?? '' ) );

        if ( empty( $old_url ) || empty( $new_url ) ) wp_send_json_error( 'Both URLs are required.' );

        global $wpdb;
        $posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_content LIKE %s",
            '%' . $wpdb->esc_like( $old_url ) . '%'
        ) );

        $count = 0;
        foreach ( $posts as $p ) {
            $new_content = str_replace( $old_url, $new_url, $p->post_content );
            if ( $new_content !== $p->post_content ) {
                wp_update_post( [ 'ID' => $p->ID, 'post_content' => $new_content ] );
                $count++;
            }
        }

        wp_send_json_success( [ 'message' => "Updated $count posts with the new URL." ] );
    }

    public static function rest_get_stats( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;
        return new WP_REST_Response( [
            'total_links'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_links" ),
            'total_suggestions' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_suggestions" ),
            'accepted'          => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_suggestions WHERE status='accepted'" ),
            'pending'           => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ailg_suggestions WHERE status='pending'" ),
        ], 200 );
    }

    /**
     * Track a click on an internal link via REST API.
     */
    public static function rest_track_click( WP_REST_Request $request ): WP_REST_Response {
        $post_id    = (int) $request->get_param( 'post_id' );
        $target_url = esc_url_raw( (string) $request->get_param( 'target_url' ) );

        if ( ! $post_id || ! $target_url ) return new WP_REST_Response( [ 'error' => 'Invalid data' ], 400 );

        $target_id = url_to_postid( $target_url );
        if ( ! $target_id ) return new WP_REST_Response( [ 'error' => 'Not a post' ], 200 );

        global $wpdb;
        $table = "{$wpdb->prefix}ailg_link_analytics";

        $wpdb->query( $wpdb->prepare(
            "INSERT INTO $table (post_id, target_id, clicks, last_update)
             VALUES (%d, %d, 1, CURRENT_TIMESTAMP)
             ON DUPLICATE KEY UPDATE clicks = clicks + 1, last_update = CURRENT_TIMESTAMP",
            $post_id, $target_id
        ) );

        return new WP_REST_Response( [ 'success' => true ], 200 );
    }
}